/* eslint-disable  func-names */
/* eslint-disable  no-console */

const Alexa = require('ask-sdk-core');
const cookbook = require('./alexa-cookbook.js');
const request = require('request');
const rp = require('request-promise-native');
const Fuse = require('fuse.js');
const https = require('https');

//=========================================================================================================================================
//TODO: The items below this comment need your attention.
//=========================================================================================================================================

const SKILL_NAME = 'Giving Guide';
const INTRO_MESSAGE = 'Welcome to Giving Guide, what cause would you like to help today?';
const GET_CHARITY_MESSAGE = 'Get charity message.';
const ALEXA_DONATE_MESSAGE = 'You can donate online or through Alexa, just say Alexa, make a donation to ';
const DEFAULT_DONATE_MESSAGE = 'Check the Alexa app for information on how to donate';
const HELP_MESSAGE = 'You can say how can I help followed by a cause like animal welfare or you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const ERROR_CANTFIND = 'Sorry, I can\'t seem to find anything for that';
const FALLBACK_MESSAGE = 'The giving guide skill can\'t help you with that.  It can help you discover charitable organizations if you say tell me how to help followed by a cause like humanitarian services. What can I help you with?';
const FALLBACK_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';


let charityData = [
  {
    title: "Saint Jude's Children Research Hospital",
    causes: [
      'treatment',
      'children',
      'prevention services',
      'Syria',
      'Syrian children',
    
    ],
    mission : [
      'is pioneering research and treatments for kids with cancer and other life-threatening diseases.'
    ],
    rating: [
      '89.83',
    
    ],
    category: [
      'Health',
    ],
    alexaDonate:[
      true,
    ],
    ein:[
      '351044585',
    ],
    site:[
      'stjude.org',
    ]
  },
  {
    title: "Doctor's Without Borders",
    causes: [
      'relief',
      'relief services',
      'doctors',
      'humanitarians',
      'humanitarian services',
    
    ],
    mission : [
      'provides lifesaving medical humanitarian care across the world.'
    ],
    rating: [
      '97.23',
    
    ],
    category: [
      'International',
    
    ],
    alexaDonate:[
      false,
    ],
    ein: [
    '133433452',
    ],
    site:[
      'doctorswithoutborders.org'
    ]
  },
  {
    title: "American Red Cross",
    causes: [
      'relief',
      'relief services',
      'disaster response',
      'human services',
      'humanitarian services',
      'blood donation',
      'natural disasters',
    
    ],
    rating: [
      '84.09',
    
    ],
    category: [
      'Human Services',
    
    ],
    alexaDonate:[
      true,
    ],
    ein: [
      '530196605',
    ]
  },
  {
    title: "World Wildlife Fund",
    causes: [
      'conservation',
      'animals',
      'wildlife',
      'pandas',
      'endangered species',
      'polar bears',
   
    ],
    rating: [
      '82.32',
    
    ],
    category: [
      'Animals',
    
    ]
  },
  {
    title: "UNICEF USA",
    causes: [
      'peace',
      'world peace',
      'children',
      'poverty',
      'clean water',
      'relief',
      'humanitarians',
      'humanitarian services'
    ],
    mission : [
      'provides healthcare, emergency relief and more humanitarian services to children around the world.'
    ],
    rating: [
      '82.19',
    
    ],
    category: [
      'International',
    
    ],
    alexaDonate:[
      false,
    ]
  }
]

const options = {
  shouldSort: true,
  threshold: 0.6,
  location: 0,
  distance: 100,
  maxPatternLength: 32,
  minMatchCharLength: 1,
  keys: [
    "title",
    "causes"
  ]
};

const fuse = new Fuse(charityData, options);


/*
function getCharityData(ein, callback){

  let URL = 'https://api.data.charitynavigator.org/v2/Organizations/' + ein + '?app_id=4eeba281&app_key=d10e23f42225ca8a264984323f7275b3'
   
  // return new pending promise
  return new Promise((callback, reject) => {
    // select http or https module, depending on reqested url
    let lib = URL.startsWith('https') ? require('https') : require('http');
   
    let request = lib.get(URL, (response) => {
      // handle http errors
      if (response.statusCode < 200 || response.statusCode > 299) {
         reject(new Error('Failed to load page, status code: ' + response.statusCode));
       }
      // temporary data holder
      let body = [];
      // on every content chunk, push it to the data array
      response.on('data', (chunk) => body.push(chunk));
      // we are done, resolve promise with those joined chunks
      response.on('end', () => {
        callback(body.join(''));
      });
    });
    // handle connection errors of the request
    request.on('error', (err) => reject(err))
  })
  
}
*/







function getData(url, callback) {  

  request(url, function (error, response, body) {
    console.log('error:', error); // Print the error if one occurred
    console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
    callback(body);
  });


  /*
  return new Promise((resolve, reject) => {
    function callback(error, response, body) {
      resolve(body);
    }
    request(url, callback);
  });
  */
}


async function getCC(_url) {
  try {
    const fulfilledValue = await get(_url);
    return fulfilledValue;
  }
  catch (rejectedValue) {
    // …
  }
}




const LaunchIntent = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'LaunchRequest'
      || (request.type === 'IntentRequest'
        && request.intent.name === 'LaunchIntent');
  },
  handle(handlerInput) {

    const speechOutput = INTRO_MESSAGE;
    const reprompt = 'Say a cause, like disaster relief to get a donation recommendation';

    return handlerInput.responseBuilder
      .speak(speechOutput)
      .reprompt(reprompt)
      .getResponse();
  },
}


const CharityHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest' 
      && request.intent.name === 'CharityIntent';
  },
  handle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    let keyword = request.intent.slots.cause.value;
    let results = fuse.search(keyword);
    let speechOutput = '';
    let cardOutput = '';
    
    console.log('keyword : ' + keyword);

    let charity = results[0];

    if(!charity){
      speechOutput = ERROR_CANTFIND;
      cardOutput = ERROR_CANTFIND;
    }

    else{

      let URI = 'https://api.data.charitynavigator.org/v2/Organizations/' + charity.ein + '?app_id=4eeba281&app_key=d10e23f42225ca8a264984323f7275b3';
    

      /*
      charityName = charity.title;
      charityRating = charity.rating; 
      charityAlexaDonate = charity.alexaDonate;
      charityMission = charity.mission;
      charitySite = charity.site;
      charityEIN = charity.ein;
      */


      speechOutput += charity.title + ' ';
      speechOutput += charity.mission + ' '


      if(charity.alexaDonate == 'true'){
       speechOutput += ALEXA_DONATE_MESSAGE + charity.title;
       cardOutput = 'To donate to ' + charity.title + ' visit ' + charity.site + ' ' + ALEXA_DONATE_MESSAGE + charity.title;
      }
      else{
       speechOutput += DEFAULT_DONATE_MESSAGE;
       cardOutput = 'To donate to ' + charity.title + ' visit ' + charity.site;
      }

      getData(URI, (response) => {
        let data = JSON.parse(response);
        speechOutput += data.ein;
      });

      return handlerInput.responseBuilder
        .speak(speechOutput)
        .withSimpleCard(SKILL_NAME, cardOutput)
        .getResponse();
      }
  },
};

const HelpHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(HELP_MESSAGE)
      .reprompt(HELP_REPROMPT)
      .getResponse();
  },
};

const FallbackHandler = {
  // 2018-May-01: AMAZON.FallackIntent is only currently available in en-US locale.
  //              This handler will not be triggered except in that locale, so it can be
  //              safely deployed for any locale.
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'AMAZON.FallbackIntent';
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(FALLBACK_MESSAGE)
      .reprompt(FALLBACK_REPROMPT)
      .getResponse();
  },
};

const ExitHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && (request.intent.name === 'AMAZON.CancelIntent'
        || request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(STOP_MESSAGE)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);

    return handlerInput.responseBuilder
      .speak('Sorry, an error occurred.')
      .reprompt('Sorry, an error occurred.')
      .getResponse();
  },
};













const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    LaunchIntent,
    CharityHandler,
    HelpHandler,
    ExitHandler,
    FallbackHandler,
    SessionEndedRequestHandler
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();
